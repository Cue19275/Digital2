/* 
 * File:   7DECODE.h
 * Author: Carlo
 *
 * Created on 2 de febrero de 2021, 21:57
 */

#ifndef 7DECODE_H
#define	7DECODE_H

#include <stdint.h>
#include <xc.h>  

void ADCinit(uint8_t vel, uint8_t chan);

#endif	/* 7DECODE_H */

