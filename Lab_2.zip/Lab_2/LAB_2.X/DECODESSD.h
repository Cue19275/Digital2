
#ifndef DECODESSD_H
#define	DECODESSD_H

#include <stdint.h>
#include <xc.h>  

void tabla(uint8_t dec);

#endif	/* DECODESSD_H */

