#ifndef ASCII_NUM_H_
#define ASCII_NUM_H_
#include <stdint.h>
#include <xc.h> 

char num_ascii(uint8_t num);
#endif