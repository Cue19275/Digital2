#ifndef usart_H_
#define usart_H_
#include <stdint.h>
#include <xc.h>  
 
void USARTconf(void);

#endif